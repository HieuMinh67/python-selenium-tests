amb = 1
amb = 2
